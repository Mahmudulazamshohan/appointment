<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppDefaultSetting extends Model
{
    //
}
